<?php


$html = file_get_html('link cần lấy');
echo $html;

?>

