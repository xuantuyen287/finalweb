<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_colors extends Model
{
    protected $table='product_colors';
}
