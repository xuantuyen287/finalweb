<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class product_sizes extends Model
{
    protected  $table="product_sizes";

}
