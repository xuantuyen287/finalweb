<?php

return [

	/*
    |--------------------------------------------------------------------------
    | Custom model
    |--------------------------------------------------------------------------
    |
    | This option allows for the extension of the product model, by pointing it to a model
    |
    */
    'product_model' => 'App\Models\Products',
    
];
